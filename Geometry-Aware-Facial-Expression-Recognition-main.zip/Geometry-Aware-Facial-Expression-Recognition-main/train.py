import torch
import torch.utils.data as data
import torch.optim as optim
from datasets.RAF_DB import RAF_DB
from datasets.graphs import Graph
from network.net_gcn import ResGCN, AttGCN_Module
from network.net_cnn import VisModel
from network.TwoStream import TowStream
import os
import argparse
from utilz import str2bool
import numpy as np
from torch.autograd import Variable
import torch.nn as nn
from termcolor import colored


def collate_fn(batch):
    batch = list(filter(lambda x: x is not None, batch))
    return torch.utils.data.dataloader.default_collate(batch)


def main(args):
    beginner = args.beginner
    stride = args.stride
    device = args.device
    batch_size = args.batch_size
    epoch = args.Epoch
    lr = args.lr
    weight_decay = args.weight_decay
    if args.gcn_only:
        model_path = "./models/gcn_only/"
        print("Activate gcn_only")
    elif args.cnn_only:
        model_path = "./models/cnn_only/"
        print("Activate cnn_only")
    else:
        model_path = "./models/two_stream/"
        print("Activate two_stream")
    num_class = args.num_class
    img_size = args.image_size
    window = args.window

    TrainSet = RAF_DB(train=True, out_size=img_size, window_size=window, cnn_only=args.cnn_only)
    TrainLoader = data.DataLoader(TrainSet, batch_size=batch_size, shuffle=True,
                                  pin_memory=False, num_workers=0, collate_fn=collate_fn)

    ValidRAF = RAF_DB(train=False, out_size=img_size, window_size=window, cnn_only=args.cnn_only)
    RAF_Loader = data.DataLoader(ValidRAF, batch_size=16, shuffle=False,
                                  pin_memory=False, num_workers=0, collate_fn=collate_fn)

    iters = int(TrainSet.__len__() / batch_size * epoch)
    if args.gcn_only:
        A = torch.from_numpy(Graph().A.astype(np.float32))
        A = Variable(A.cuda(device=device), requires_grad=False)
        net = ResGCN(
            module=AttGCN_Module,
            structure=[1, 2, 3, 3],
            block='Bottleneck',
            A=A,
            data_shape=(3, 2, 1, 68),
            num_class=num_class,
            mem_size=64
        )
        # net = nn.DataParallel(net, device_ids=[0, 1])
        net.cuda(device=device)
        optimizer = optim.SGD(net.parameters(), weight_decay=weight_decay, momentum=0.9, lr=lr)
        scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, eta_min=1e-5, T_max=iters)
        if args.load_checkpoint:
            print("loading checkpoint...")
            net.load_state_dict(torch.load("./models/gcn_only/raf_db.pth"))
        criterion = nn.CrossEntropyLoss().cuda()

    elif args.cnn_only:
        net = VisModel(num_class=num_class)
        optimizer = optim.SGD(net.parameters(), weight_decay=weight_decay, momentum=0.9, lr=lr)
        scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, eta_min=1e-5, T_max=iters)
        # net = nn.DataParallel(net, device_ids=[0, 1])
        net.cuda(device=device)
        if args.load_checkpoint:
            print("loading checkpoint...")
            net.load_state_dict(torch.load("./models/cnn_only/raf_db.pth"))
        criterion = nn.CrossEntropyLoss().cuda()

    else:
        A = torch.from_numpy(Graph().A.astype(np.float32))
        A = Variable(A.cuda(device=device), requires_grad=False)
        net = TowStream(
            module=AttGCN_Module,
            structure=[1, 2, 3, 3],
            block='Bottleneck',
            A=A,
            data_shape=(3, 2, 1, 68),
            num_class=num_class,
            mem_size=64
        )
        if args.load_checkpoint:
            print("loading checkpoint...")
            net.load_state_dict(torch.load("./models/two_stream/net.pth"))
        else:
            print("loading independent checkpoint")
            net.cnn.load_state_dict(torch.load("./models/cnn_only/raf_db.pth"))
            net.gcn.load_state_dict(torch.load("./models/gcn_only/raf_db.pth"))

        # Frozen
        for params in net.parameters():
            params.requires_grad = False

        net.train(False)
        train_params = []

        for params in net.classifier.parameters():
            params.requires_grad = True
            train_params += [params]

        for params in net.aff.parameters():
            train_params += [params]
            params.requires_grad = True

        base_params = []
        for params in net.cnn.fc7.parameters():
            params.requires_grad = True
            base_params += [params]
        for params in net.cnn.fc6.parameters():
            params.requires_grad = True
            base_params += [params]
        for params in net.cnn.bn6.parameters():
            params.requires_grad = True
            base_params += [params]
        for params in net.gcn.main_stream[-1].scn.bn_up.parameters():
            params.requires_grad = True
            base_params += [params]
        for params in net.gcn.main_stream[-1].scn.conv_up.parameters():
            params.requires_grad = True
            base_params += [params]

        optimizer = optim.SGD([
            {'params': train_params},
            {'params': base_params, 'lr': lr/5},
        ], weight_decay=weight_decay, momentum=0.9, lr=lr)
        scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=iters, eta_min=1e-7)
        #  net = nn.DataParallel(net, device_ids=[0, 1])
        net.cuda(device=device)
        criterion = nn.CrossEntropyLoss().cuda()

    print("# Training Samples: " + str(TrainSet.__len__()) + "; Testing Samples: "
          + str(ValidRAF.__len__()))

    for i in range(beginner, epoch):
        cls_loss = 0
        trainSamples = 0
        numCorrTrain = 0

        for batch_idx, (geo_tensor, vis_tensor, seq_tensor, emo_tensor) in enumerate(TrainLoader):

            trainSamples += emo_tensor.size(0)
            optimizer.zero_grad()
            if args.gcn_only:
                net.train(True)
                geo_tensor = Variable(geo_tensor.cuda(device=device), requires_grad=False)
                vis_tensor = Variable(vis_tensor.cuda(device=device), requires_grad=False)
                emo_tensor = Variable(emo_tensor.cuda(device=device), requires_grad=False)
                out, feature = net(geo_tensor, vis_tensor)
                loss = criterion(out, emo_tensor.squeeze())
            elif args.cnn_only:
                net.train(True)
                seq_tensor = Variable(seq_tensor.cuda(device=device), requires_grad=False)
                emo_tensor = Variable(emo_tensor.cuda(device=device), requires_grad=False)
                out, feature = net(seq_tensor)
                loss = criterion(out, emo_tensor.squeeze())
            else:
                net.classifier.train(True)
                net.aff.train(True)
                net.cnn.bn6.train(True)
                net.gcn.main_stream[-1].scn.bn_up.train(True)
                geo_tensor = Variable(geo_tensor.cuda(device=device), requires_grad=False)
                vis_tensor = Variable(vis_tensor.cuda(device=device), requires_grad=False)
                seq_tensor = Variable(seq_tensor.cuda(device=device), requires_grad=False)
                emo_tensor = Variable(emo_tensor.cuda(device=device), requires_grad=False)
                out, feature = net(geo_tensor, vis_tensor, seq_tensor)
                loss = criterion(out, emo_tensor.squeeze())

            loss.backward()
            optimizer.step()
            scheduler.step()

            label_t = emo_tensor.detach().squeeze().cuda()
            _, label_p = torch.max(out, 1)
            numCorrTrain += label_p.eq(label_t.data).cpu().sum()

            cls_loss += loss * geo_tensor.size(0)
            if batch_idx % 50 == 49 or batch_idx == 0:
                print('#batch: %3d; loss_cls: %3.4f; learning rate: %.4e.'
                      % (batch_idx + 1, loss * geo_tensor.size(0), optimizer.param_groups[0]['lr']))

        avg_cls = cls_loss / trainSamples
        trainAccuracy = (int(numCorrTrain) / trainSamples) * 100
        print('Train: Epoch = %3d | CLS Loss = %.4f | Train Samples = %3d | Train Accuracy = %.4f;'
              % (i + 1, avg_cls, trainSamples, trainAccuracy))

        if i % stride == (stride - 1):
            torch.save(net.state_dict(), os.path.join(model_path, 'net_epoch_' + str(i + 1).zfill(3) + '.pth'))

        # Validation
        net.train(False)
        validSamples = 0
        numCorrValid = 0
        for batch_idx, (geo_valid, vis_valid, seq_valid, emo_valid) in enumerate(RAF_Loader):
            geo_valid = Variable(geo_valid.cuda(device), requires_grad=False)
            vis_valid = Variable(vis_valid.cuda(device), requires_grad=False)
            seq_valid = Variable(seq_valid.cuda(device), requires_grad=False)
            emo_valid = Variable(emo_valid.cuda(device), requires_grad=False)
            with torch.no_grad():
                if args.gcn_only:
                    logits, _ = net(geo_valid, vis_valid)
                elif args.cnn_only:
                    logits, _ = net(seq_valid)
                else:
                    logits, _ = net(geo_valid, vis_valid, seq_valid)
            label_t = emo_valid.detach().squeeze()
            _, label_p = torch.max(logits.data, 1)
            numCorrValid += (label_p == label_t.squeeze()).sum()
            validSamples += seq_valid.size(0)

        validAccuracy = (int(numCorrValid) / validSamples) * 100

        print(
            'Train: Epoch = %3d | Valid Samples = %3d' % (i + 1, validSamples)
            + colored(' | RAF-DB Accuracy = %.4f', 'red') % validAccuracy
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # For Dataset and Record
    parser.add_argument("--image_size", type=int, default=224, help="width and height should be identical")
    parser.add_argument("--image_channel", type=int, default=3)
    parser.add_argument("--num_frame", type=int, default=1)
    parser.add_argument("--stride", type=int, default=1, help='the stride for saving models')
    parser.add_argument("--window", type=int, default=49, help="# local patch size")
    parser.add_argument("--num_class", type=int, default=7, help="# of the classes")

    # For Training
    parser.add_argument("--load_checkpoint", type=str2bool, default=False)
    parser.add_argument("--batch_size", type=int, default=40)
    parser.add_argument("--beginner", type=int, default=0)
    parser.add_argument('--Epoch', type=int, default=300)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=5e-4)
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument("--cnn_only", type=str2bool, default=False)
    parser.add_argument("--gcn_only", type=str2bool, default=False)
    args = parser.parse_args()

    main(args)
