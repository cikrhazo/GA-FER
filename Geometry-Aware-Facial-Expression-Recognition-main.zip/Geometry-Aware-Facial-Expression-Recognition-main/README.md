# [Geometry-Aware-Facial-Expression-Recognition](https://github.com/RickZ1010/Geometry-Aware-Facial-Expression-Recognition)

## Intordction
This is the implementation of the following paper:

**Geometry-Aware Facial Expression Recognition via Attentive Graph Convolutional Networks**

*Rui Zhao, Tianshan Liu, Zixun Huang, Daniel P.K. Lun, and Kin-Man Lam*

<p align = "justify"> 
Abstract: Learning discriminative representations with good robustness from facial observations serves as a fundamental step towards intelligent facial expression recognition (FER). In this paper, we propose a novel geometry-aware FER learning framework to boost the FER performance based on both the geometric and appearance knowledge. Specifically, we propose an encoding strategy for facial landmarks, and adopt a graph convolutional network (GCN) to fully explore the structural information of the facial components behind different expressions. To further investigate the dependency between the structure deformation and appearance changes for the different expressions, we propose to align the geometric and local-appearance information in graph-based learning through an early-stage fusion. On the other hand, a convolutional neural network (CNN) is applied to the whole facial observation to learn the global characteristics of different expressions. The features from these two networks are fused into a comprehensive high-semantic representation, which promotes the FER reasoning from both visual and structural perspectives. Moreover, to facilitate the networks to concentrate on the most informative facial regions and components, we introduce the attention mechanisms into both the GCN and CNN streams, as well as the final feature fusion stage, which enhance the reliability of the learned representations for effective FER. Extensive experiments on two challenging FER benchmarks demonstrate that the attentive graph-based learning on the facial geometry can significantly increase the FER accuracy and achieve state-of-the-art performance. Furthermore, the insensitivity of the geometric information to the appearance variations greatly improves the generalization and robustness of the system in the cross-domain experiments and robustness tests.
</p>

## Dependencies
Python >= 3.6.5, PyTorch >= 1.6, cuda-10.1, [face-alignment](https://github.com/1adrianb/face-alignment)

## Framework

<p  align="center">    
<img src="https://github.com/RickZ1010/Geometry-Aware-Facial-Expression-Recognition/blob/main/figs/fig2.png" width=900/>
</p>

Thanks to YAN Sijie for the released code on Github (https://github.com/yysijie/st-gcn)
